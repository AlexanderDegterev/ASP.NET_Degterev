﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Ex02
{
    class Item
    {
        string itemName;
        double itemPrice;
        int itemQuantity;

        public string name
        {
            get 
            {
                return itemName;
            }
            set
            {
                itemName = value;
            }
        }
        public double price
        {
            get
            {
                return itemPrice;
            }
            set
            {
                itemPrice = value;
            }
        }
        public int quantity
        {
            get
            {
                return itemQuantity;
            }
            set
            {
                itemQuantity = value;
            }
        }

        public double itemCost()
        {
            return price * quantity;
        }

        public Item(string name, double price, int quantity)
        {
            this.name = name;
            this.price = price;
            this.quantity = quantity;

        }
    }


    struct ItemStruct
    {
        string itemName;
        double itemPrice;
        int itemQuantity;

        public string name
        {
            get 
            {
                return itemName;
            }
            set
            {
                itemName = value;
            }
        }
        public double price
        {
            get
            {
                return itemPrice;
            }
            set
            {
                itemPrice = value;
            }
        }
        public int quantity
        {
            get
            {
                return itemQuantity;
            }
            set
            {
                itemQuantity = value;
            }
        }

        public double itemCost()
        {
            return price * quantity;
        }

        public ItemStruct(string name, double price, int quantity)
        {
            itemName = name;
            itemPrice = price;
            itemQuantity = quantity;

        }
    }
    
    
    class Program
    {
        static void Main(string[] args)
        {
            Random ran = new Random();
            ArrayList arr = new ArrayList();
            ArrayList arrS = new ArrayList();
            double sum = 0, sumS = 0 ;

            // class
            DateTime begin = DateTime.Now;
            for (int i = 0; i < 100000; i++)
            {
                arr.Add(new Item("Item #" + i, ran.NextDouble() * 10000, ran.Next(10000)));
            }
            
            foreach (Item it in arr)
            {
                sum += it.itemCost();
            }
            DateTime end = DateTime.Now;
            Console.WriteLine("Стоимость всех товаров = {0}, время выполнения - {1}", sum, end - begin);

            // structure
            begin = DateTime.Now;
            for (int i = 0; i < 100000; i++)
            {
                arrS.Add(new ItemStruct("Item #" + i, ran.NextDouble() * 10000, ran.Next(10000)));

            }

            foreach (ItemStruct it in arrS)
            {
                sumS += it.itemCost();
            }
            end = DateTime.Now;
            Console.WriteLine("Стоимость всех товаров = {0}, время выполнения - {1}", sumS, end - begin);




            Console.ReadKey();
	
        }
    }
}
