﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03
{
    class Triangle
    {

        int a_side, b_side, c_side;

        public int a
        {
            get
            {
                return a_side;
            }

            set
            {
                a_side = value;
            }
        }
        public int b
        {
            get
            {
                return b_side;
            }

            set
            {
                b_side = value;
            }
        }
        public int c
        {
            get
            {
                return c_side;
            }

            set
            {
                c_side = value;
            }
        }

        public Triangle(int a, int b, int c)
        {
            this.a = a;
            Console.WriteLine("Длина стороны а - {0}", a);
            this.b = b;
            Console.WriteLine("Длина стороны b - {0}", b);
            this.c = c;
            Console.WriteLine("Длина стороны c - {0}\n", c);
        }


        public static int inputValidInt()
        {
            bool isNumber = false;
            int x = 0, count = 0;
            string str = String.Empty;

            while (!isNumber)
            {
                if (count>0)
                    Console.WriteLine(str + " - это не число, введите число");
                str = Console.ReadLine();
                
                isNumber = int.TryParse(str, out x);
                count++; 
    
            }
            return x;
        }

        public void triangleStart()
        {
            if (!sidesValidate())
            {
                Console.WriteLine("Такого треугольника не существует\n");

            }
            else
            {
                getTriangleType();
                
            }

        }


        public bool sidesValidate()
        {
            return ((a + b > c) & (a + c > b) & (b + c > a));
        }

        public enum TriangleType
        {
            ostroug, tupoug, prjamoug
        }
        

        public void blackOnYellow(string str)
        {
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine(str);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            
        }


        public TriangleType getTriangleType()
        {
            

            if ((a * a + b * b > c * c) & (b * b + c * c > a * a) & (a * a + c * c > b * b))
            {
                blackOnYellow(string.Format("\nТреугольник со сторонами {0}, {1}, {2} является остроугольным\n", a, b, c));
                return TriangleType.ostroug;
            }
            else if ((a * a + b * b == c * c) & (b * b + c * c == a * a) & (a * a + c * c == b * b))
            {
                blackOnYellow(string.Format("\nТреугольник со сторонами {0}, {1}, {2} является прямоугольным\n", a, b, c));
                
                return TriangleType.prjamoug;
            }
            else
            {
                blackOnYellow(string.Format("\nТреугольник со сторонами {0}, {1}, {2} является тупоугольным\n", a, b, c));
                
                return TriangleType.tupoug;
            }

            
                
                

            
        }

        

        public void showChangeMenu()
        {
            
            Console.WriteLine("Хотите изменить сторону a(1), b(2) или c(3)? (Для выхода нажмите (q))");

            switch (Console.ReadLine())
            {
                case "1":
                    Console.WriteLine("Текущее значение стороны а - {0}, изменить на: ", a);
                    a = inputValidInt();
                    while (!sidesValidate())
                    {
                        Console.WriteLine("Такого треугольника не существует, введите сторону ещё раз:");
                        a = inputValidInt();
                        
                    }
                    Console.WriteLine("Измененное значение стороны а - " + a);
                    
                    getTriangleType();
                    Program.showMenu(this);

                    break;

                case "2":
                    Console.WriteLine("Текущее значение стороны b - {0}, изменить на: ", b);
                    
                    b = inputValidInt();
                    while (!sidesValidate())
                    {
                        Console.WriteLine("Такого треугольника не существует, введите сторону ещё раз:");
                        b = inputValidInt();
                        
                    }
                    Console.WriteLine("Измененное значение стороны b - " + b);
                    
                    getTriangleType();
                    Program.showMenu(this);
                    
                    break;

                case "3":
                    Console.WriteLine("Текущее значение стороны c - {0}, изменить на: ", c);
                    c = inputValidInt();
                    while (!sidesValidate())
                    {
                        Console.WriteLine("Такого треугольника не существует, введите сторону ещё раз:");
                        c = inputValidInt();
                        
                    }
                    Console.WriteLine("Измененное значение стороны c - " + c);
                    
                    getTriangleType();
                    Program.showMenu(this);

                    break;

                case "q":
                    Environment.Exit(0);
                    break;

                default:
                    showChangeMenu();
                    break;
            }
        }

    }



    class Program
    {
        public static void showMenu(Triangle t1)
        {

            Console.WriteLine("Хотите изменить(1) или создать(2) новый треугольник? (Для выхода нажмите (q))");


            switch (Console.ReadLine())
            {
                case "1":
                    t1.showChangeMenu();
                    break;

                case "2":
                    Console.WriteLine("Введите три стороны треугольника:");
                    t1 = new Triangle(Triangle.inputValidInt(), Triangle.inputValidInt(), Triangle.inputValidInt());
                    t1.triangleStart();
                    showMenu(t1);
                    break;

                case "q":
                    Environment.Exit(0);
                    break;

                default:
                    showMenu(t1);
                    break;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Создание треугольника, введите три стороны:");
            Triangle t1 = new Triangle(Triangle.inputValidInt(), Triangle.inputValidInt(), Triangle.inputValidInt());
            t1.triangleStart();
            showMenu(t1);


            Console.ReadKey();
        }
    }
}
