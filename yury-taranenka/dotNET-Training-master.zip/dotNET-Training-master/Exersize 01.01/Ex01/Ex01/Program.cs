﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex01
{

    class LinearFunction
    {
        double paramA, paramB;

        public double a
        {
            get
            {
                return paramA;
            }
            set
            {
                paramA = value;
            }
        }

        public double b
        {
            get
            {
                return paramB;
            }
            set
            {
                paramB = value;
            }
        }

        

        public double calculateFunction(double x)
        {
            return a * x + b;
        }
    }
    
    class Program
    {
               
        

        

        static void Main(string[] args)
        {
            double x = 0;
            Console.WriteLine("Функция вида y = a*x + b");

            LinearFunction l = new LinearFunction();

            Console.WriteLine("Введите значение Х");
            
            bool isNumber = false;
          
            while (!isNumber)
            {
                isNumber = Double.TryParse(Console.ReadLine(), out x);
            }
            
            Console.WriteLine("Хотите изменить параметры функции? (y/n)");
            if (Console.ReadLine() == "y")
            {
                Console.WriteLine("Параметр а");
                isNumber = false;
                double a = 0, b = 0;
                
                while (!isNumber)
                {
                    isNumber = Double.TryParse(Console.ReadLine(), out a);
                }
                l.a = a;
                
                Console.WriteLine("Параметр b");
                isNumber = false;
                
                while (!isNumber)
                {
                    isNumber = Double.TryParse(Console.ReadLine(), out b);
                }
                l.b = b;
            }
            

            

            Console.WriteLine("Значение функции {0}",l.calculateFunction(x));
            
            Console.ReadKey();
        }
    }
}
