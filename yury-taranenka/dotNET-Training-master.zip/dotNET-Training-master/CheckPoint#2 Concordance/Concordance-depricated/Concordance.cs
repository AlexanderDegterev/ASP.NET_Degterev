﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Concordance
{
    class Concordance
    {

        private int pageStringCount;
        private string filePath;
        string saveFilePath;

        public string SaveFilePath
        {
            get { return saveFilePath; }
            set { saveFilePath = value; }
        }
        char[] punctuationCharacters = new char[] { ' ', '!', '.', ',', '?', ':', ';', '-', '(', ')', '"' };

        IDictionary<string, List<int>> wordLineCountDict = new Dictionary<string, List<int>>();
        ICollection<string> outputList = new List<string>();

        public ulong iteration = 0;
        public IDictionary<string, List<int>> WordLineCountDict
        {
            get { return wordLineCountDict; }
            set { wordLineCountDict = value; }
        }
        
        
        public string FilePath
        {
            get { return filePath; }
            set { filePath = value; }
        }
        public int PageStringCount
        {
            get { return pageStringCount; }
            set { pageStringCount = value; }
        }

        public IEnumerable<string> LoadText()
        {
            ICollection<string> lines = new List<string>();
                        
            try
            {
                using (StreamReader sreader = new StreamReader(FilePath, Encoding.Default))
                {
                    while (sreader.Peek() >= 0)
                    {
                        lines.Add(sreader.ReadLine().ToLower());
                    }
                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return lines;
        }

        public void GenerateConcordance(IEnumerable<string> lines)
        {
            int lineNumber = 1;
            foreach (var line in lines)
            {
                string[] words = line.Split(punctuationCharacters, StringSplitOptions.RemoveEmptyEntries);

                foreach (var word in words)
                {
                    if (word.Length == 1 && !Char.IsLetter(word[0]))
                        continue;
                   
                    if (!Char.IsLetter(word[0]) && !Char.IsSymbol('\''))
                        continue;

                    if (Char.IsNumber(word[0]))
                        continue;
                    
                    if (!WordLineCountDict.ContainsKey(word))
                    {
                        WordLineCountDict.Add(word, new List<int>(){1, lineNumber});
                    }
                    else
                    {
                        WordLineCountDict[word][0]++;

                        if (!WordLineCountDict[word].Contains(lineNumber))
                        {
                            WordLineCountDict[word].Add(lineNumber);
                        }
                        
                    }
                }
                lineNumber++;
            }
        }

        public void DisplayConcordance()
        {
            var d = WordLineCountDict.OrderBy(x => x.Key);
            foreach (var item in d)
            {
                
                Console.Write("{0,-20}-{1,-3}:  ", item.Key, item.Value[0]);
                for (int i = 1; i < item.Value.Count; i++)
                {
                    Console.Write("{0} ", item.Value[i]);
                    
                }
                Console.WriteLine();
            }
        }

        public void DisplayItem(KeyValuePair<string, List<int>> item)
        {
            Console.Write("{0,-20}-{1,-3}:  ", item.Key, item.Value[0]);
            for (int i = 1; i < item.Value.Count; i++)
            {
                Console.Write("{0} ", item.Value[i]);
            }
            Console.WriteLine();
        }

        private void OutputItem(KeyValuePair<string, List<int>> item)
        {
            string str = string.Empty;
            str = String.Format("{0}{1,-3}:  ", item.Key.PadRight(20, '.'), item.Value[0]);
            for (int i = 1; i < item.Value.Count; i++)
            {
                str = String.Concat(str,String.Format("{0} ", item.Value[i]));
                iteration++;
            }
            str = String.Concat(str, "\n");
            outputList.Add(str);
        }


        public void DisplayAlpha()
        {
            var d = WordLineCountDict.OrderBy(x => x.Key);
            char startLetter = d.ElementAt(0).Key[0];
            Console.WriteLine("---{0}---",startLetter.ToString().ToUpper());
            foreach (var item in d)
            {
                if (item.Key[0] == startLetter)
                {
                    DisplayItem(item);
                }
                else
                {
                    startLetter = item.Key[0];
                    Console.WriteLine("---{0}---", startLetter.ToString().ToUpper());
                    DisplayItem(item);
                }
            }
        }

        public void GenerateOutputLines()
        {
            var d = WordLineCountDict.OrderBy(x => x.Key);
            char startLetter = d.ElementAt(0).Key[0];
            outputList.Add(String.Format("---{0}---", startLetter.ToString().ToUpper()));
            foreach (var item in d)
            {
                if (item.Key[0] == startLetter)
                {
                    OutputItem(item);
                }
                else
                {
                    startLetter = item.Key[0];
                    outputList.Add(String.Format("---{0}---", startLetter.ToString().ToUpper()));
                    OutputItem(item);
                }
            }
        }

       
        public void Display()
        {
            foreach (var line in outputList)
            {
                Console.WriteLine(line);
            }
        }


        public void SaveToFile()
        {
            try
            {
                using (StreamWriter swriter = new StreamWriter(SaveFilePath, false, Encoding.Default))
                {
                    foreach (var item in outputList)
                    {
                        swriter.WriteLine(item);
                    }


                }

                Console.WriteLine(String.Concat("Файл ",SaveFilePath," успешно записан"));

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }









    }
}
