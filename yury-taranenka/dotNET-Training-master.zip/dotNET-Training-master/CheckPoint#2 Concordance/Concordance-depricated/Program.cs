﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concordance
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] strings = new string[]
            {
                "qwerty rtyty rty r.rty,  rtyrtyr !",
                "qwerty rtyty rty r.rty,  rtyrtyr !",
                "qwerty rtyty rty r.rty,  rtyrtyr !",
                "EErty!!! rtyty? rty r.rty,  rtyrtyr !",
                "qwerty rtyty rty r.rty,  rtyrtyr !",
                "24 rtyty rty r.rty,  rtyrtyr !"
            };


            Concordance con = new Concordance();
            Console.WriteLine("Введите название файла");
            string fileName = Console.ReadLine();
            var sw = System.Diagnostics.Stopwatch.StartNew();
            con.FilePath = "../../" + fileName;
            con.SaveFilePath = "../../Concordance-" + fileName;

            con.GenerateConcordance(con.LoadText());
            sw.Stop();
            Console.WriteLine("Время генерации {0} мс", sw.ElapsedMilliseconds);
            sw.Restart();
            con.GenerateOutputLines();
            sw.Stop();
            Console.WriteLine("Время генерации {0} мс", sw.ElapsedMilliseconds);
            sw.Restart();
            foreach (var item in con.WordLineCountDict.OrderByDescending(x => x.Value[0]).Take(10))
            {
                Console.WriteLine("{0} - {1}",item.Key, item.Value[0]);
            }
            sw.Stop();
            Console.WriteLine("Время генерации {0} мс", sw.ElapsedMilliseconds);
            sw.Restart();
            con.SaveToFile();
            sw.Stop();
            Console.WriteLine("Время генерации {0} мс", sw.ElapsedMilliseconds);
            Console.WriteLine("Итерация № {0}", con.iteration);

            char ch = '\'';
            Console.WriteLine(Char.IsPunctuation(ch));

            Console.ReadKey();
        }
    }
}
