﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concordance2
{
    struct Word
    {
        List<int> lineNumbers = new List<int>();
        public int NumberOfOccurances
        {
            get { return LineNumbers.Count; }
        }
        
        public List<int> LineNumbers
        {
            get { return lineNumbers; }
            set { lineNumbers = value; }
        }

        private Word() { }

        public Word(int firstOccurance)
        {
            this.LineNumbers.Add(firstOccurance);
        }
    }
}
