﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concordance2
{
    class ConcordancePresenter
    {
        private int pageStringCount; //number of lines per page
        IDictionary<string, Word> wordOccuranceDict = new Dictionary<string, Word>(); //main concordance dictionary
        ICollection<string> outputList = new List<string>();
        int currentLineNumber = 0;
        IOManager io;  
        Parser parser;

        private ICollection<string> OutputList
        {
            get { return outputList; }
            set { outputList = value; }
        }

        private IDictionary<string, Word> WordOccuranceDict
        {
            get { return wordOccuranceDict; }
            set { wordOccuranceDict = value; }
        }

        private int CurrentLineNumber
        {
            get { return currentLineNumber; }
            set { currentLineNumber = value; }
        }

        private int PageStringCount
        {
            get { return pageStringCount; }
            set { pageStringCount = value; }
        }

        public ConcordancePresenter()
        {
            io = new IOManager();
            parser = new Parser();
            io.LineRead += io_LineRead;  //event subscription
            Console.WriteLine("Input number of lines in page:");
            PageStringCount = Convert.ToInt32(Console.ReadLine());
        }
    
        private void AppendWordsToConcordance(ICollection<string> words)  //append new portion of words to concordance
        {
            foreach (var word in words)
            {
                if (!WordOccuranceDict.ContainsKey(word))
                {
                    WordOccuranceDict.Add(word, new Word(CurrentLineNumber));
                }
                else
                {
                    WordOccuranceDict[word].LineNumbers.Add(currentLineNumber);
                }
            }
        }

        // Generate output data about word in format ( *word* ... *NumberOfOccurences* : *line1*..lineN*  )
        private void OutputItemOnlyLines(KeyValuePair<string, Word> item)
        {
            string str = string.Empty;
            str = String.Format("{0}{1,-4}: ", item.Key.PadRight(20, '.'), item.Value.NumberOfOccurances);
            foreach (var lineNumber in item.Value.LineNumbers.Distinct())
            {
                str = String.Concat(str, lineNumber, " ");
            }
            
            str = String.Concat(str, "\n");
            OutputList.Add(str);
        }

        // Generate output data about word in format ( *word* ... *NumberOfOccurences* : *page*(*line1*..lineN*) )
        private void OutputItemPages(KeyValuePair<string, Word> item)
        {
            string str = String.Format("{0}{1,-4}: ", item.Key.PadRight(20, '.'), item.Value.NumberOfOccurances);
            int currentPage = 0;
            int lastPage = (item.Value.LineNumbers[0] % PageStringCount > 0) 
                ? item.Value.LineNumbers[0] / PageStringCount + 1 
                : item.Value.LineNumbers[0] / PageStringCount;
            str = String.Concat(str, lastPage, "(");
            var distinctSequence = item.Value.LineNumbers.Distinct();
            foreach (var lineNumber in distinctSequence)
            {
                currentPage = (lineNumber % PageStringCount > 0) ? lineNumber / PageStringCount + 1 : lineNumber / PageStringCount;
                
                if (currentPage == lastPage)
                {
                    str = String.Concat(str, lineNumber - (currentPage - 1) * PageStringCount, ", ");
                }
                else
                {
                    int i = distinctSequence.SkipWhile(x => x == lineNumber).FirstOrDefault();
                    if (i > 0 && i / PageStringCount != currentPage)
	                {
                        str = String.Concat(str.Substring(0, str.Length - 2), ")  ");
	                }
                    str = String.Concat(str, currentPage, "(", lineNumber - (currentPage - 1) * PageStringCount, ", ");
                }
                lastPage = currentPage;
            }
            str = String.Concat(str.Substring(0, str.Length - 2), ")", "\n");
            OutputList.Add(str);
        }

        public void GenerateOutputLines()   //sorting and beautifying concordance and get ready to any output
        {
            if (WordOccuranceDict.Count > 0)
            {
                var d = WordOccuranceDict.OrderBy(x => x.Key);
                char startLetter = d.ElementAt(0).Key[0];
                OutputList.Add(String.Format("---{0}---", startLetter.ToString().ToUpper()));
                foreach (var item in d)
                {
                    if (item.Key[0] == startLetter)
                    {
                        OutputItemPages(item);
                    }
                    else
                    {
                        startLetter = item.Key[0];
                        OutputList.Add(String.Format("---{0}---", startLetter.ToString().ToUpper()));
                        OutputItemPages(item);
                    }
                }
            }
            
        }

        public void LoadText()
        {
            io.LoadText();
        }

        public void SaveToFile()
        {
            io.SaveToFile(OutputList);
        }

        public void Display()
        {
            io.DisplayConcordance(OutputList);
        }

        void io_LineRead(object sender, IOEventArgs e)   // event reaction
        {
            CurrentLineNumber++;
            AppendWordsToConcordance(parser.ParseStringWithSplit(e.Line));
        }
    }
}
