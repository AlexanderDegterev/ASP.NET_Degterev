﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concordance2
{
    class Program
    {
        static void Main(string[] args)
        {
            ConcordancePresenter con = new ConcordancePresenter();
            var sw = System.Diagnostics.Stopwatch.StartNew();
            con.LoadText();
            con.GenerateOutputLines();
            sw.Stop();
            Console.WriteLine("Генерация конкорданса {0}", sw.ElapsedMilliseconds);
            sw.Restart();
            con.SaveToFile();
            sw.Stop();
            Console.WriteLine("Сохранение в файл {0}", sw.ElapsedMilliseconds);
            
            Console.ReadKey();
        }
    }
}
