﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Concordance2
{
    class IOManager
    {
        string filePath;
        string saveFilePath;

        private string SaveFilePath
        {
            get { return saveFilePath; }
            set { saveFilePath = value; }
        }

        private string FilePath
        {
            get { return filePath; }
            set { filePath = value; }
        }
        string line;

        public IOManager()
        {
            Console.WriteLine("Input filename: ");
            string fileName = Console.ReadLine();
            FilePath = String.Concat("../../", fileName);
            SaveFilePath = String.Concat("../../Concordance-", fileName);
        }

        public event EventHandler<IOEventArgs> LineRead;   // let know that one line of text is already read

        public string LoadText()  //reads text file line by line
        {
            try
            {
                using (StreamReader sreader = new StreamReader(FilePath, Encoding.UTF8))
                {
                    while (sreader.Peek() >= 0)
                    {
                        line = sreader.ReadLine().ToLower();  
                        if (LineRead != null)  //event invokation
                        {
                            LineRead(this, new IOEventArgs(line));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return null;
        }
      
        public void DisplayConcordance(ICollection<string> outputList)  // console output
        {
            foreach (var item in outputList)
            {
                Console.WriteLine(item);
            }
        }
           
        public void SaveToFile(ICollection<string> outputList) // file output
        {
            if (outputList.Count > 0)
            {
                try
                {
                    using (StreamWriter swriter = new StreamWriter(SaveFilePath, false, Encoding.UTF8))
                    {
                        foreach (var item in outputList)
                        {
                            swriter.WriteLine(item);
                        }
                    }

                    Console.WriteLine("{0} {1} {2}", "File", SaveFilePath.Substring(6), "successfully written!");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            
        }
    }
}
