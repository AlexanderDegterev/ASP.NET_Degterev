﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concordance2
{
    class IOEventArgs : EventArgs
    {
        public string Line  // string with portion of text
        {
            get ; 
            private set;
        }

        public IOEventArgs(string line)
        {
            this.Line = line;
        }
    }
}
