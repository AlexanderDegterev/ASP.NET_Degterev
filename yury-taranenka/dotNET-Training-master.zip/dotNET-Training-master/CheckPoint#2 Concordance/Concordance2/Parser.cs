﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concordance2
{
    class Parser
    {
        char[] punctuationCharacters = new char[] { ' ', '!', '.', ',', '?', ':', ';', '-', '(', ')', '"', '\n', '\r', '\t', '=', '^','{', '|' };

        private bool ContainsChars(char ch)  //method that used by parse method
        {
            foreach (var item in punctuationCharacters)
            {
                if (ch == item)
                {
                    return true;
                }
            }
            return false;
        }

        public ICollection<string> ParseString(string stringLine) //parse method with custom word splitting
        {
            int lastWordIndex = 0;
            int firstWordIndex = 0;
            string word = String.Empty;
            ICollection<string> words = new List<string>();

            foreach (char ch in stringLine)
            {
                if (!ContainsChars(ch) & !Char.IsNumber(ch))
                {
                    lastWordIndex++;
                    continue;
                }
                else
                {
                    word = stringLine.Substring(firstWordIndex, lastWordIndex - firstWordIndex);
                    lastWordIndex++;
                    firstWordIndex = lastWordIndex;
                }

                if (!String.IsNullOrEmpty(word))
                {
                    words.Add(word);
                }
            }
            return words;
        }

        public ICollection<string> ParseStringWithSplit(string stringLine)  //parse method with standart string.split()
        {
            ICollection<string> wordsList = new List<string>();
            string[] words = stringLine.Split(punctuationCharacters, StringSplitOptions.RemoveEmptyEntries);

            foreach (var word in words)
            {
                if (word.Length == 1 && !Char.IsLetter(word[0]) || !Char.IsLetter(word[0]) && !Char.IsSymbol('\'') || Char.IsNumber(word[0]))
                {
                    continue;
                }
                wordsList.Add(word);
            }
            return wordsList;
        }
    }
}
