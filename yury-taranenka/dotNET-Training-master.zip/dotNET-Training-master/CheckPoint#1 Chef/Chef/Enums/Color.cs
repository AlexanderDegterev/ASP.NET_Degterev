﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public enum Color
    {
        NoColor = 0,
        White,
        Green,
        Red,
        Yellow
    }
}
