﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public enum CookType //percentageLoss
    {
        Fresh = 0, //loss of mass and nutritions when cooking
        Boil = 15,
        Stew = 22,
        Fry = 30
    }
}
