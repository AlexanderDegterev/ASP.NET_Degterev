﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public enum Shape
    {
        NoShape = 0,
        Round,
        Ellipse,
        Oblong
    }
}
