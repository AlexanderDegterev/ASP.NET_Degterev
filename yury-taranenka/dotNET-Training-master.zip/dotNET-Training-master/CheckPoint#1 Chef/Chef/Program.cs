﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chef
{
    class Program
    {
        static void Main(string[] args)
        {
            
            InitializeProducts init = new InitializeProducts();
            ISalad salad = new Salad();

            List<string> saladComponents = new List<string>() { "Potato", "Broccoli", "GreenOnion", "Sorrel", "Tomato", "SourCream" };

            init.LoadNutritions(saladComponents[0]);
            salad.Add(new RootCrop()
            {
                Name = saladComponents[0],
                Proteins = init.proteins,
                Fats = init.fats,
                Carbohydrates = init.carbohydrates,
                Color = init.color,
                CookType = CookType.Boil,
                Mass = 400
            });

            init.LoadNutritions(saladComponents[1]);
            salad.Add(new CabbageCrop()
            {
                Name = saladComponents[1],
                Proteins = init.proteins,
                Fats = init.fats,
                Carbohydrates = init.carbohydrates,
                Color = init.color,
                Mass = 400
            });

            init.LoadNutritions(saladComponents[2]);
            salad.Add(new SpicyHerbCrop()
            {
                Name = saladComponents[2],
                Proteins = init.proteins,
                Fats = init.fats,
                Carbohydrates = init.carbohydrates,
                Color = init.color,
                Mass = 100
            });

            init.LoadNutritions(saladComponents[3]);
            salad.Add(new GreenCrop()
            {
                Name = saladComponents[3],
                Proteins = init.proteins,
                Fats = init.fats,
                Carbohydrates = init.carbohydrates,
                Color = init.color,
                Mass = 200
            });

            init.LoadNutritions(saladComponents[4]);
            salad.Add(new FruitCrop()
            {
                Name = saladComponents[4],
                Proteins = init.proteins,
                Fats = init.fats,
                Carbohydrates = init.carbohydrates,
                Color = init.color,
                Mass = 250
            });

            init.LoadNutritions(saladComponents[5]);
            salad.Add(new Flavoring()
            {
                Name = saladComponents[5],
                Proteins = init.proteins,
                Fats = init.fats,
                Carbohydrates = init.carbohydrates,
                Color = init.color,
                Mass = 200
            });


            foreach (var item in salad)
            {
                Console.WriteLine("Калорийность {0}: {1} ккал", item.Name, item.CalculateCalories());
            }
            Console.WriteLine();


            salad.Sort("calories",true);

            foreach (var item in salad)
            {
                Console.WriteLine("Калорийность: {1} - {0}", item.Name, item.CalculateCalories());
            }
            Console.WriteLine();


            Console.WriteLine(" Общая калорийность салата: {0:.000} ккал", salad.CalculateCalories());

            Console.WriteLine();


            Console.WriteLine("Продукты, попадающие в диапазон калорийности от {0} до {1} (после обработки).", 50, 200);
            Console.WriteLine();
            var set = salad.FindSetOfProducts(50, 200);
            foreach (var item in set)
            {
                Console.WriteLine(item.Name);
            }
            
            Console.ReadKey();

            

        }
    }
}
