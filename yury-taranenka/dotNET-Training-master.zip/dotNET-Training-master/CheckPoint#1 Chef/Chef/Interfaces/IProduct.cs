﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public interface IProduct
    {
        string Name { get; }
        Color Color { get;}
        double Mass { get;}
        double Proteins { get; }
        double Fats { get; }
        double Carbohydrates { get; }

        double CalculateCalories();


    }
}
