﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public interface IPeel
    {
        int PeelPercentageLoss { get; }
        void Peel();
    }
}
