﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public interface ISalad : ICollection<IProduct>
    {
        string SaladColor { get; }
        void MakeSalad();
        double CalculateCalories();
        void Sort(string type, bool descending);
        IEnumerable<IProduct> FindSetOfProducts(double minCalories, double maxCalories);

        
    }
}
