﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public interface ITaste
    {
        string SpecialTaste { get; }
    }
}
