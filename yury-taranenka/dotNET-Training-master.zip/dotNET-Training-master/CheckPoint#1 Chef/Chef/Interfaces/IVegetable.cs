﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public interface IVegetable : IProduct
    {
        int ChopPercentageLoss { get; }
        Shape Shape { get; }
        CookType CookType { get; }
        void Cook(CookType type);
        void Chop();
    }
}
