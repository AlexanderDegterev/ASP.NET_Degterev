﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public interface ILeaf
    {
        int RootPercentageLoss { get; }
        void CutRoot();
    }
}
