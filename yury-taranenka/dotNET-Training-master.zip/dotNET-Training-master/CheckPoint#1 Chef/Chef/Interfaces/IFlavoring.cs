﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public interface IFlavoring : IProduct
    {
        string Consistency { get; }
    }
}
