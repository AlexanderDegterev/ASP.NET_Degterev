﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public class Flavoring : Product, IFlavoring 
    {
        string consistency = "Жидкость";
        public string Consistency
        {
            get { return consistency; }
        }
    }
}
