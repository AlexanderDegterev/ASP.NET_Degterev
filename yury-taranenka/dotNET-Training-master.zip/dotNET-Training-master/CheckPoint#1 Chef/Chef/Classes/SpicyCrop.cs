﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public class SpicyCrop : Vegetable, ITaste 
    {
        
        public string SpecialTaste
        {
            get { return Name + "'s taste"; }
        }
    }
}
