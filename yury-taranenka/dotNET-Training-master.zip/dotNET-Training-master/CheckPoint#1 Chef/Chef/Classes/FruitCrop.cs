﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public class FruitCrop : Vegetable, IHasSeeds 
    {
        bool removeSeeds = false; //check if necessary to remove seeds when cooking( pepper)
        int seedsPercentageLoss = 10; //loss of mass when cut seeds

        public int SeedsPercentageLoss
        {
            get { return seedsPercentageLoss; }
            
        }
        public bool RemoveSeeds
        {
            get { return removeSeeds; }
        }

        public void CutSeeds()
        {
            if (RemoveSeeds)
            {
                Mass -= Mass * SeedsPercentageLoss / 100;
            }
        }
    }
}
