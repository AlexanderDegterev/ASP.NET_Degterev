﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public abstract class Product : IProduct
    {
        string name = "";
        double mass, proteins, fats, carbohydrates;
        Color color = Color.NoColor;
        const double caloriesPerGram = 4.1; //calories per gram carbohydrates & proteins
        const double caloriesPerGramFats = 9.3; //calories per gram fats

        public string Name
        {
            get{return name;}
            set { name = value; }
        }

        public virtual Color Color
        {
            get { return color; }
            set { color = value; }
        }

        public double Mass
        {
            get { return mass; }
            set { mass = value; }
        }

        public double Proteins
        {
            get { return proteins; }
            set { proteins = value; }
        }

        public double Fats
        {
            get { return fats; }
            set { fats = value; }
        }

        public double Carbohydrates
        {
            get { return carbohydrates; }
            set { carbohydrates = value; }
        }

        public double CalculateCalories()
        {
            return Proteins * (Mass / 100) * caloriesPerGram + 
                Carbohydrates * (Mass / 100) * caloriesPerGram +
                Fats * (Mass / 100) * caloriesPerGramFats;
        }
    }
}
