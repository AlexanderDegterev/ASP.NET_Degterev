﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public class SpicyHerbCrop : SpicyCrop, ILeaf 
    {
        int rootPercentageLoss = 15; //loss of mass when cut root

                
        public int RootPercentageLoss
        {
            get { return rootPercentageLoss; }
        }

        public void CutRoot()
        {
            Mass -= Mass * RootPercentageLoss / 100;
        }
    }
}
