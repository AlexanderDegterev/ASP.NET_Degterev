﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public abstract class Vegetable : Product, IVegetable 
    {
        int chopPercentageLoss = 4; //loss of mass when chop vegetable
        Shape shape = Shape.NoShape;
        CookType cookType = CookType.Fresh;

        public Shape Shape
        {
            get { return shape; }
            set { shape = value; }
        }

        public CookType CookType
        {
            get { return cookType; }
            set { cookType = value; }
        }

        public void Cook(CookType type)
        {
            Mass -= Mass*(int)type/100;
            Proteins -= Proteins * (int)type / 200; //loss of nutritions is a half of mass loss
            Fats -= Fats * (int)type / 200;
            Carbohydrates -= Carbohydrates * (int)type / 200;
        }

        public void Chop()
        {
            Mass -= Mass * (ChopPercentageLoss / 100);
        }

        public int ChopPercentageLoss
        {
            get { return chopPercentageLoss; }
        }
    }
}
