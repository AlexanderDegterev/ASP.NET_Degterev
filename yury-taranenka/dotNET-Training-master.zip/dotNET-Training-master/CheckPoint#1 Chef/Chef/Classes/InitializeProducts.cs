﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;

namespace Chef
{
    public class InitializeProducts
    {
        public double proteins = 1, carbohydrates = 2, fats = 1;
        public Color color = Color.NoColor;
        
        public void LoadNutritions(string name)
        {
            string strColor = "";
            try
            {
                using (XmlReader xreader = XmlReader.Create("../../XMLInitiation.xml"))
                {
                
                    while (xreader.Read())
                    {
                        xreader.ReadToFollowing("Product");
                        xreader.MoveToFirstAttribute();
                        if (xreader.Value == name)
                        {
                            xreader.ReadToFollowing("Proteins");
                            proteins = xreader.ReadElementContentAsDouble();
                       
                            xreader.ReadToFollowing("Fats");
                            fats = xreader.ReadElementContentAsDouble();

                            xreader.ReadToFollowing("Carbohydrates");
                            carbohydrates = xreader.ReadElementContentAsDouble();

                            xreader.ReadToFollowing("Color");
                            strColor = xreader.ReadElementContentAsString();
                        }
                        
                    }

                    switch (strColor)
                    {
                        case "White": color = Color.White;
                            break;
                        case "Red": color = Color.Red;
                            break;
                        case "Yellow": color = Color.Yellow;
                            break;
                        default: color = Color.NoColor;
                            break;
                    }
                    
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
