﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public class RootCrop : Vegetable, IPeel, IRoot 
    {
        int peelPercentageLoss = 15; //loss of mass when peel vegetable
        int leafPercentageLoss = 5; //loss of mass when cut leafs

        public int PeelPercentageLoss
        {
            get { return peelPercentageLoss; }
        }
        public void Peel()
        {
            Mass -= Mass * PeelPercentageLoss / 100; ;
        }

        public int LeafPercentageLoss
        {
            get { return leafPercentageLoss; }
        }

        public void CutLeafs()
        {
            Mass -= Mass * LeafPercentageLoss / 100;
        }
    }
}
