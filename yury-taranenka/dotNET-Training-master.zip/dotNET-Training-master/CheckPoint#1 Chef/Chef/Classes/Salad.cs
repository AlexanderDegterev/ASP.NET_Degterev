﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public class Salad : ISalad 
    {
        ICollection<IProduct> salad = new List<IProduct>();
        public string SaladColor
        {
            get { return Color.Green.ToString(); }
        }

        public double CalculateCalories()
        {
            
            MakeSalad();

            return salad.Aggregate(0.0,(x,y) => x + y.CalculateCalories());
        }



       

        #region Sorting
        Dictionary<String, Func<IProduct, object>> sortDict =
                                      new Dictionary<string, Func<IProduct, object>>()
        {
            {"calories", x => x.CalculateCalories()},
            {"name", x => x.Name},
            {"fats", x => x.Fats},
            {"proteins", x => x.Proteins},
            {"carbohydrates", x => x.Carbohydrates},
            {"color", x => x.Color},
            {"mass", x => x.Mass},
            
        };


       
        public void Sort(string type, bool descending = false)
        {
            type = type.ToLower().Trim();
            
            if (!descending && sortDict.ContainsKey(type))
            {
                salad = salad.OrderBy(sortDict[type]).ToList();
            }
            else
            {
                if (sortDict.ContainsKey(type))
                {
                    salad = salad.OrderByDescending(sortDict[type]).ToList();
                }
                else
                {
                    Console.WriteLine("Такого поля не существет, отсортировано по умолчанию(по имени).");
                    salad = salad.OrderByDescending(x => x.Name).ToList();
                }
            }
        }
        #endregion

        public IEnumerable<IProduct> FindSetOfProducts(double minCalories, double maxCalories)
        {
            foreach (var item in salad)
            {
                if (item.CalculateCalories() > minCalories & item.CalculateCalories() < maxCalories)
                    yield return item;
            }
        }

        # region ICollection
        public void Add(IProduct item)
        {
            salad.Add(item);
        }

        public void Clear()
        {
            salad.Clear();
        }

        public bool Contains(IProduct item)
        {
            return salad.Contains(item);
        }

        public void CopyTo(IProduct[] array, int arrayIndex)
        {
            salad.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return salad.Count; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool Remove(IProduct item)
        {
            return salad.Remove(item);
        }

        public IEnumerator<IProduct> GetEnumerator()
        {
            return salad.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        #endregion


        public void MakeSalad()
        {
            foreach (var item in salad)
            {
                if (item is IRoot)
                {
                    (item as IRoot).CutLeafs();
                    Console.WriteLine("{0} - очищены от листьев", item.Name);
                }

                if (item is ILeaf)
                {
                    (item as ILeaf).CutRoot();
                    Console.WriteLine("{0} - очищены от корней", item.Name);
                }

                if (item is IPeel)
                {
                    (item as IPeel).Peel();
                    Console.WriteLine("{0} - очищены от кожуры и корки", item.Name);
                }

                if (item is IHasSeeds && (item as IHasSeeds).RemoveSeeds)
                {
                    (item as IHasSeeds).CutSeeds();
                    Console.WriteLine("{0} - очищены от семян", item.Name);
                }

                if (item is IVegetable)
                {
                    (item as IVegetable).Chop();
                    Console.WriteLine("{0} - порезаны", item.Name);
                    (item as IVegetable).Cook((item as IVegetable).CookType);
                    Console.WriteLine("{0} - приготовлены", item.Name);
                }
                
            }
        }

        
    }
}
