﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public class SpicyBulbCrop : SpicyCrop, IPeel 
    {
        int peelPercentageLoss = 5; //loss of mass when peel vegetable
        public int PeelPercentageLoss
        {
            get { return peelPercentageLoss; }
        }

        public void Peel()
        {
            Mass -= Mass * PeelPercentageLoss / 100;
        }
    }
}
