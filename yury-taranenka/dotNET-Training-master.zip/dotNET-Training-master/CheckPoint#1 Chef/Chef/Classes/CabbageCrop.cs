﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chef
{
    public class CabbageCrop : Vegetable, IHead
    {
        int leafPercentageLoss = 5; //loss of mass when cut leafs
        int rootPercentageLoss = 10; //loss of mass when cut root
        public int LeafPercentageLoss
        {
            get { return leafPercentageLoss; }
        }
        public int RootPercentageLoss
        {
            get { return rootPercentageLoss; }
        }

        public void CutLeafs()
        {
            Mass -= Mass * LeafPercentageLoss / 100;
        }

        public void CutRoot()
        {
            Mass -= Mass * RootPercentageLoss / 100;
        }

        
    }
}
