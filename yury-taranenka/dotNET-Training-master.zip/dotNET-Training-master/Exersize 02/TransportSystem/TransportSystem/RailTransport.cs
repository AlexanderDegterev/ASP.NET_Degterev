﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public abstract class RailTransport : TransportItem, ICollection<Wagon>
    {
        string type = "Рельсовый транспорт";
        
            

        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }

        public ICollection<Wagon> wagons = new List<Wagon>();
        #region ICollection
        public void Add(Wagon item)
        {
            wagons.Add(item);
        }

        public void Clear()
        {
            wagons.Clear();
        }

        public bool Contains(Wagon item)
        {
            return wagons.Contains(item);
        }

        public void CopyTo(Wagon[] array, int arrayIndex)
        {
            wagons.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return wagons.Count; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool Remove(Wagon item)
        {
            return wagons.Remove(item);
        }

        public IEnumerator<Wagon> GetEnumerator()
        {
            return  wagons.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        #endregion
        
        public override void Information()
        {
            base.Information();
            Console.WriteLine("Имеет {0} вагона(ов). ", wagons.Count);
        }

    }
}
