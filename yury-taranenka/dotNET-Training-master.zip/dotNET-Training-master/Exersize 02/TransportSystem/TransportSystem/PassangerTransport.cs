﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public abstract class PassangerTransport : WheelTransport, IPassenger
    {
        int passangerNumber = 20;
        string type = "Пассажирский транспорт";

        public int PassangerNmber
        {
            get { return passangerNumber; }
            set { passangerNumber = value; }
        }

        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }

        public void PickupPassenger()
        {
            Console.WriteLine("Подобрали {0} пассажиров.", PassangerNmber);
        }

        
        
    }
}
