﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class TransportSystem : ICollection<TransportItem>
    {
        ICollection<TransportItem> transportSystem = new List<TransportItem>();

        #region ICollection
        public void Add(TransportItem item)
        {
            transportSystem.Add(item);
        }
        
        public void Clear()
        {
            transportSystem.Clear();
        }

        public bool Contains(TransportItem item)
        {
            return transportSystem.Contains(item);
        }

        public void CopyTo(TransportItem[] array, int arrayIndex)
        {
            transportSystem.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return transportSystem.Count; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool Remove(TransportItem item)
        {
            return transportSystem.Remove(item);
        }

        public IEnumerator<TransportItem> GetEnumerator()
        {
            return transportSystem.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        #endregion

        public IEnumerable<TransportItem> GetTransportItem(DateTime start, DateTime end)
        {
            foreach (var i in transportSystem)
	        {
                if (i.ManufacturedDate > start & i.ManufacturedDate < end)
                     yield return i;
	        }
        }

        public void Sort(Comparison<TransportItem> compareDelegate)
        {
            var list = transportSystem.ToList();
            list.Sort(compareDelegate);
            transportSystem = list;
        }





        Dictionary<String, Func<TransportItem, object>> sortDict =
                                      new Dictionary<string, Func<TransportItem, object>>()
        {
            {"averagespeed", x => x.AverageSpeed},
            {"name", x => x.Name},
            {"consumption", x => x.Consumption},
            {"manufactureddate", x => x.ManufacturedDate},
            {"drive", x => x.Drive(100)},
            
        };

        public void SortWithDict(string a)
        {

            a = a.ToLower();
            a = new string(a.ToCharArray().Where(x => !Char.IsWhiteSpace(x)).ToArray());

            if (sortDict.ContainsKey(a))
            {
                transportSystem = transportSystem.OrderBy(sortDict[a]).ToList();
            }
            else
            {
                transportSystem = transportSystem.OrderBy(x => x.Name).ToList();
            }
            
           
        }



        public void SortWithDict(string a, bool descending = false)
        {
            if (!descending)
            {
                SortWithDict(a);
            }
            else
            {
                a = a.ToLower();
                a = new string(a.ToCharArray().Where(x => !Char.IsWhiteSpace(x)).ToArray());

                if (sortDict.ContainsKey(a))
                {
                    transportSystem = transportSystem.OrderByDescending(sortDict[a]).ToList();
                }
                else
                {
                    transportSystem = transportSystem.OrderByDescending(x => x.Name).ToList();
                }
            }
            
        }

        public void LinqSort(SortType a)
        {
            switch (a)
            {
                case SortType.AverageSpeed:
                    transportSystem = transportSystem.OrderBy(x => x.AverageSpeed).ToList();
                    break;
                case SortType.Name:
                    transportSystem = transportSystem.OrderBy(x => x.Name).ToList();
                    break;
                case SortType.Consumption:
                    transportSystem = transportSystem.OrderBy(x => x.Consumption).ToList();
                    break;
                case SortType.ManufacturedDate:
                    transportSystem = transportSystem.OrderBy(x => x.ManufacturedDate).ToList();
                    break;
                case SortType.DriveTime:
                    transportSystem = transportSystem.OrderBy(x => x.Drive(100)).ToList();
                    break;
                default:
                    break;
            }
            
            
                       
        }
        
    }
}
