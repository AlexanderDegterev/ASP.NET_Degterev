﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class Truck : WheelTransport, ICargo, IFuelOil
    {
        int capacity = 20;
        int volume = 600;
        string type = "Фура";
        
        public int Capacity
        {
            get { return capacity; }
            set { capacity = value; }
        }

        public void Load()
        {
            Console.WriteLine("Загрузили {0} тонн", Capacity);
        }

        public double RemainingDistance
        {
            get { return Volume/Consumption; }
        }

        public int Volume
        {
            get
            {
                return volume;
            }
            set
            {
                volume = value;
            }
        }

        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }



        
    }
}
