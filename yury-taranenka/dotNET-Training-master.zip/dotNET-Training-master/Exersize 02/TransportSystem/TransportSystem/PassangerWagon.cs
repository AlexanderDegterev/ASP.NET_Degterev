﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class PassangerWagon : Wagon, IPassenger
    {
        int passangerNumber = 54;
        string type = "Пассажирский вагон";

        public int PassangerNmber
        {
            get { return passangerNumber; }
            set { passangerNumber = value; }
        }

        public void PickupPassenger()
        {
            Console.WriteLine("Подобрали {0} пассажиров.", PassangerNmber);
        }

    }
}
