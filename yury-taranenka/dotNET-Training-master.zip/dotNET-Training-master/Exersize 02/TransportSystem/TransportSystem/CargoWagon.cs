﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class CargoWagon : Wagon, ICargo
    {
        int capacity = 66;
        string type = "Грузовой вагон";

        public int Capacity
        {
            get { return capacity; }
            set { capacity = value; } 
        }

        public void Load()
        {
            Console.WriteLine("Загрузили {0} тонн", Capacity);
        }
    }
}
