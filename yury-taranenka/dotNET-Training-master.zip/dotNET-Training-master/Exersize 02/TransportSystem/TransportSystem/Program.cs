﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransportSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            
            ItemBuilder ib = new ItemBuilder();
            TransportSystem coll = new TransportSystem();
            Random ran = new Random();
            for (int i = 0; i < ran.Next(1, 3); i++)
            {
                coll.Add(ib.CreateElectroTrain(ran.Next(1, 10)));
                coll.Add(ib.CreateTrain(ran.Next(1, 10)));
            }

            var population = ib.PopulateRailWayTransport(ran.Next(10), ran.Next(10), ran.Next(10), ran.Next(10), ran.Next(10))
                                    .Concat(ib.PopulateWheelTransport(ran.Next(10), ran.Next(10), ran.Next(10), ran.Next(10)));
            
            foreach (var item in population)
            {
                coll.Add(item);
            }
            coll.SortWithDict("manufactured date", true);

            foreach (var item in coll)
            {
                Console.WriteLine("{0}, {1}, {2}, {3}, {4}", item.Name, item.ManufacturedDate, item.Consumption,item.AverageSpeed, item.Drive(100));
            }
            
            //coll.LinqSort(SortType.Name);

            //coll.Sort(TransportComparer.CompareByManufacturedDate);

            //foreach (var i in coll)
            //{

            //    i.Information();
            //}

            
            //foreach (var i in coll)
            //{
            //    if (i is IPassenger)
            //    {
            //        Console.WriteLine(i.Name);
            //        (i as IPassenger).PickupPassenger();
            //        Console.WriteLine();
            //    }
            //}

            //foreach (var i in coll.GetTransportItem(new DateTime(1980, 1, 1), new DateTime(1990, 1, 1)))
            //{
            //    Console.WriteLine("{0} - {1:dd.MM.yyyy}", i.Name, i.ManufacturedDate);
            //}
            Console.ReadKey();
        }
    }
}
