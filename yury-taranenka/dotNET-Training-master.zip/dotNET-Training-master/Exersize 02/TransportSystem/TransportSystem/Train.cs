﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class Train : RailTransport, IFuelOil
    {
        int volume = 500;
        string type = "Поезд";
        public double RemainingDistance
        {
            get { return Volume/Consumption; }
        }

        public int Volume
        {
            get
            {
                return volume;
            }
            set
            {
                volume = value;
            }
        }

        
        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }

        public override void Information()
        {
            base.Information();
            Console.WriteLine("Размер бака: {0} л (потребление топлива {1} л/100 км), этого количества топлива хватит на {2:.2} км, эту дистанцию он преодолеет за {3:dd\\.hh\\:mm\\:ss}.", Volume, Consumption, RemainingDistance, Drive(RemainingDistance));
        }
    }
}
