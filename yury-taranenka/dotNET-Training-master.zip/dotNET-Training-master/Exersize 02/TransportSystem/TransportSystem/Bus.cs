﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class Bus : Car
    {
        double consumption = 15;
        int passangerNumber = 20;
        int volume = 100;
        string type = "Автобус";

        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }
    }
}
