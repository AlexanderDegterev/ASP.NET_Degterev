﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class TrolleyBus : PassangerTransport, IElectric
    {
        string type = "Троллейбус";
        int voltage = 600;
        public int Voltage
        {
            get { return voltage; }
            set { voltage = value; }
        }

        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }
    }
}
