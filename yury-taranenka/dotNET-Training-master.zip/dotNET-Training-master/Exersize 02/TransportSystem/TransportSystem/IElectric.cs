﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public interface IElectric:IEngine
    {
        int Voltage { get; set; }
    }
}
