﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public interface IEngine
    {
        double Consumption { get; set; }

        TimeSpan Drive(double distance);
    }
}
