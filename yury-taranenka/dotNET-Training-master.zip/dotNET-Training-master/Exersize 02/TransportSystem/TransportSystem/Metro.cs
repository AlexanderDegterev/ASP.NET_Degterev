﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class Metro : ElectroTrain
    {
        string type = "Метро";

        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }
    }
}
