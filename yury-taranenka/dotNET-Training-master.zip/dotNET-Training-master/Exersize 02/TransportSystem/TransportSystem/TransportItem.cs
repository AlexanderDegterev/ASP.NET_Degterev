﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public abstract class TransportItem:ITransportItem, IEngine
    {
        int averageSpeed = 50;
        DateTime manufacturedDate = new DateTime(1960, 01, 01);
        double consumption = 20;
        string type = "Транспортная единица";
        int itemNumber;
        

        public int ItemNumber
        {
            get { return itemNumber; } 
            set { itemNumber = value; }
        } 
        
        

        #region ITransportItem
        public int AverageSpeed
        {
            get
            {
                return averageSpeed;
            }
            set
            {
                averageSpeed = value;
            }
        }

        public DateTime ManufacturedDate
        {
            get
            {
                return manufacturedDate;
            }
            set { manufacturedDate = value; }

        }
        public string Type
        {
            get { return type; }
        }
        public virtual string Name
        {
            get { return type + " № " + ItemNumber; }
        }

        public virtual void Information()
        {
            Console.WriteLine("\n{0} произведен {1} г, передвигается со скоростью {2} км/ч.", Name, ManufacturedDate.ToShortDateString(), AverageSpeed);
        }

        #endregion 

        #region IEngine
        public TimeSpan Drive(double distance)
        {
            return new TimeSpan((long)(distance / ((double)AverageSpeed / ((long)3600 * 10000000))));
        }
        

        public double Consumption
        {
            get
            {
                return consumption;
            }
            set
            {
                consumption = value;
            }
        }
        #endregion


    }
}
