﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class ElectroTrain : RailTransport, IElectric
    {
        int voltage = 800;
        string type = "Электропоезд";
        
        
        public int Voltage
        {
            get { return voltage; }
            set { voltage = value; }
        }

        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }

        

        public override void Information()
        {
            base.Information();
            Console.WriteLine("Дистанцию в 100 км преодолевает за {0:dd\\.hh\\:mm\\:ss}. Напряжение контактной сети {1} вольт.", Drive(100), Voltage);
        }

        
    }
}
