﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class Car : PassangerTransport, IFuelOil
    {
        int passengerNumber = 4;
        int volume = 50;
        double consumption = 10;
        string type = "Машина";

        public double RemainingDistance
        {
            get { return Volume/Consumption; }
        }

        public int Volume
        {
            get
            {
                return volume;
            }
            set
            {
                volume = value;
            }
        }

        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }
    }
}
