﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class Tram : ElectroTrain
    {
        string type = "Трамвай";

        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }
    }
}
