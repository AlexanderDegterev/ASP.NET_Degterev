﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public static class TransportComparer
    {   
        public static int CompareByName(TransportItem x, TransportItem y)
        {
            return (x == null & y == null) ? 0 : (x == null & y != null) ? -1 : (y == null & x != null) ? 1 :
               string.Compare(x.Name, y.Name);
		}

        public static int CompareByAverageSpeed(TransportItem x, TransportItem y)
        {
            return (x.AverageSpeed == y.AverageSpeed) ? 0 : (x.AverageSpeed > y.AverageSpeed) ? 1 : -1;
        }

        public static int CompareByConsumption(TransportItem x, TransportItem y)
        {
            return (x.Consumption == y.Consumption) ? 0 : (x.Consumption > y.Consumption) ? 1 : -1;
        }

        public static int CompareByDriveTime(TransportItem x, TransportItem y)
        {
            return (x.Drive(100) == y.Drive(100)) ? 0 : (x.Drive(100) > y.Drive(100)) ? 1 : -1;
        }

        public static int CompareByManufacturedDate(TransportItem x, TransportItem y)
        {
            return (x == null & y == null) ? 0 : (x == null & y != null) ? -1 : (y == null & x != null) ? 1 :
               DateTime.Compare(x.ManufacturedDate, y.ManufacturedDate);
        }

	}

}
