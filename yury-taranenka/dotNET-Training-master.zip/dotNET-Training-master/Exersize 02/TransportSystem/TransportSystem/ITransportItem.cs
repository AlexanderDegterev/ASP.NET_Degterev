﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public interface ITransportItem
    {
        string Type { get; }
        string Name { get; }
        int AverageSpeed { get; set; }
        DateTime ManufacturedDate { get; set; }

        void Information();
    }
}
