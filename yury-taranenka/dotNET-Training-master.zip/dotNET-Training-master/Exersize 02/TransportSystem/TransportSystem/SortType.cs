﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public enum SortType
    {
        AverageSpeed, Name, Consumption, ManufacturedDate, DriveTime
    }
}
