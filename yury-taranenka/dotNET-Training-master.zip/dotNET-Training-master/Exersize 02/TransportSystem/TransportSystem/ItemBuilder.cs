﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public class ItemBuilder
    {
        int itemNum;
        Random ran = new Random();

        public int ItemNum
        {
            get { return itemNum; }
            set { itemNum = value; }
        }

        
        public DateTime RandomDate()
        {
            TimeSpan between = new DateTime(2015, 04, 01) - new DateTime(1960, 01, 01);
            int ranDays = ran.Next(between.Days);
            
            return new DateTime(1960, 01, 01) + new TimeSpan(between.Days - ranDays,0,0,0);
        }

        #region CreateRailWay
        public CargoWagon CreateCargoWagon()
        {
            return new CargoWagon()
            {
                Capacity = ran.Next(20, 70)
            };
        }
        public PassangerWagon CreatePassangerWagon()
        {
            return new PassangerWagon()
            {
                PassangerNmber = ran.Next(20, 70)
            };
        }
        public ElectroTrain CreateElectroTrain( int wagonCount)
        {
            ItemNum++;
            
            ElectroTrain el = new ElectroTrain() 
            { 
                
                ItemNumber = ItemNum, 
                ManufacturedDate = RandomDate(), 
                AverageSpeed = ran.Next(1, 100), 
                Consumption = ran.Next(1, 20), 
                Voltage = ran.Next(500, 800),
                
            };

            for (int i = 0; i < wagonCount; i++)
			{
                el.Add(CreatePassangerWagon());
			}


            return el;
        }

        public Train CreateTrain(int wagonCount)
        {
            ItemNum++;
            
            Train tr = new Train()
            {
                ItemNumber = ItemNum,
                ManufacturedDate = RandomDate(),
                AverageSpeed = ran.Next(1, 100),
                Consumption = ran.Next(1, 20),
                Volume = ran.Next(400, 1000)
            };

            for (int i = 0; i < wagonCount; i++)
            {
                tr.Add(CreatePassangerWagon());
            }

            return tr;

        }

        public CargoTrain CreateCargoTrain(int wagonCount)
        {
            ItemNum++;

            CargoTrain tr = new CargoTrain()
            {
                ItemNumber = ItemNum,
                ManufacturedDate = RandomDate(),
                AverageSpeed = ran.Next(1, 100),
                Consumption = ran.Next(1, 20),
                Volume = ran.Next(400, 1000)
            };

            for (int i = 0; i < wagonCount; i++)
            {
                tr.Add(CreateCargoWagon());
            }

            return tr;

        }

        public Metro CreateMetro(int wagonCount)
        {
            ItemNum++;

            Metro el = new Metro()
            {
                ItemNumber = ItemNum,
                ManufacturedDate = RandomDate(),
                AverageSpeed = ran.Next(1, 100),
                Consumption = ran.Next(1, 20),
                Voltage = ran.Next(500, 800)
            }; 

            for (int i = 0; i < wagonCount; i++)
            {
                el.Add(CreatePassangerWagon());
            }


            return el;
        }
        public Tram CreateTram(int wagonCount)
        {
            ItemNum++;

            Tram el = new Tram()
            {
                ItemNumber = ItemNum,
                ManufacturedDate = RandomDate(),
                AverageSpeed = ran.Next(1, 100),
                Consumption = ran.Next(1, 20),
                Voltage = ran.Next(500, 800)
            };

            for (int i = 0; i < wagonCount; i++)
            {
                el.Add(CreatePassangerWagon());
            }


            return el;
        }
        #endregion 

        #region CreateWheel

        public Truck CreateTruck()
        {
            ItemNum++;

            Truck wheel = new Truck()
            {
                ItemNumber = ItemNum,
                ManufacturedDate = RandomDate(),
                AverageSpeed = ran.Next(1, 100),
                Consumption = ran.Next(1, 20),
                Capacity = ran.Next(1, 20),
                Volume = ran.Next(200, 600)
            };

            return wheel;
        }

        public TrolleyBus CreateTrolleyBus()
        {
            ItemNum++;

            TrolleyBus wheel = new TrolleyBus()
            {
                ItemNumber = ItemNum,
                ManufacturedDate = RandomDate(),
                AverageSpeed = ran.Next(1, 100),
                Consumption = ran.Next(1, 20),
                PassangerNmber = ran.Next(1, 40),
                Voltage = ran.Next(500, 800)
            };

            return wheel;
        }

        public Car CreateCar()
        {
            ItemNum++;

            Car wheel = new Car()
            {
                ItemNumber = ItemNum,
                ManufacturedDate = RandomDate(),
                AverageSpeed = ran.Next(1, 100),
                Consumption = ran.Next(1, 20),
                PassangerNmber = ran.Next(1, 4),
                Volume = ran.Next(1, 50)
            };

            return wheel;
        }

        public Bus CreateBus()
        {
            ItemNum++;

            Bus wheel = new Bus()
            {
                ItemNumber = ItemNum,
                ManufacturedDate = RandomDate(),
                AverageSpeed = ran.Next(1, 100),
                Consumption = ran.Next(1, 30),
                PassangerNmber = ran.Next(1, 40),
                Volume = ran.Next(1, 200)
            };

            return wheel;
        }
        #endregion



        public IEnumerable<TransportItem> PopulateRailWayTransport(int electroTrain, int train, int cargoTrain, int metro, int tram)
        {
            

            for (int i = 0; i < electroTrain; i++)
            {
                yield return CreateElectroTrain(ran.Next(1, 10));
            }

            for (int i = 0; i < train; i++)
            {
                yield return CreateTrain(ran.Next(1, 10));
            }

            for (int i = 0; i < cargoTrain; i++)
            {
                yield return CreateCargoTrain(ran.Next(1, 10));
            }

            for (int i = 0; i < metro; i++)
            {
                yield return CreateMetro(ran.Next(1, 10));
            }

            for (int i = 0; i < tram; i++)
            {
                yield return CreateTram(ran.Next(1, 10));
            }
            
        }

        public IEnumerable<TransportItem> PopulateWheelTransport(int truck, int trolleybus, int car, int bus)
        {


            for (int i = 0; i < truck; i++)
            {
                yield return CreateTruck();
            }

            for (int i = 0; i < trolleybus; i++)
            {
                yield return CreateTrolleyBus();
            }

            for (int i = 0; i < car; i++)
            {
                yield return CreateCar();
            }

            for (int i = 0; i < bus; i++)
            {
                yield return CreateBus();
            }

            
        }
    }
}
