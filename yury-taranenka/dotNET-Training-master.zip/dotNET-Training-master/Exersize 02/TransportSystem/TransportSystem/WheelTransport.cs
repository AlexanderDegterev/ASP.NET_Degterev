﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportSystem
{
    public abstract class WheelTransport : TransportItem
    {
        string type = "Колесный траснпорт";

        public override string Name
        {
            get { return type + " № " + ItemNumber; }
        }
    }
}
